import { json, error } from '@sveltejs/kit';
import type { RequestHandler } from './$types';
import { getCDNDiscoveryUrls } from '$lib/bnk48';

const MAX_COUNT = 250; // Hard cap — prevents abuse via huge batch requests
const ALLOWED_TYPES = new Set(['product', 'group']);
const ALLOWED_ORDERS = new Set(['asc', 'desc']);

async function checkUrl(targetUrl: string): Promise<boolean> {
    const controller = new AbortController();
    const timeout = setTimeout(() => controller.abort(), 4000);
    try {
        const resp = await fetch(targetUrl, { method: 'HEAD', signal: controller.signal });
        clearTimeout(timeout);
        return resp.ok;
    } catch {
        clearTimeout(timeout);
        return false;
    }
}

function getExtraSkusCandidates(id: string, mainFilename: string): string[] {
    const candidates: string[] = [];
    const dashNumMatch = mainFilename.match(/^(.*-)(\d+)(\.jpg|\.png)$/i);
    if (dashNumMatch) {
        const [_, prefix, currentNumStr, ext] = dashNumMatch;
        const currentNum = parseInt(currentNumStr);
        const isPadded = currentNumStr.startsWith('0') && currentNumStr.length > 1;
        const padLen = currentNumStr.length;

        // Expanded range for SKU/Aroma etc. up to 10
        const maxRange = prefix.toLowerCase() === 'sku-' ? 10 : 8;
        for (let i = 1; i <= maxRange; i++) {
            if (i === currentNum) continue;
            const num = isPadded ? i.toString().padStart(padLen, '0') : i.toString();
            candidates.push(`https://img.bnk48cdn.net/shop/product/${id}/${prefix}${num}${ext}`);
        }
    }

    // CGM48 base handling
    if (mainFilename === 'cgm48.png' || mainFilename.startsWith('cgm48-')) {
        const currentIsBase = mainFilename === 'cgm48.png';
        for (let i = 1; i <= 8; i++) {
            if (currentIsBase && i === 1) continue;
            if (mainFilename === `cgm48-${i}.png`) continue;
            candidates.push(`https://img.bnk48cdn.net/shop/product/${id}/cgm48-${i}.png`);
        }
        if (!currentIsBase) {
            candidates.push(`https://img.bnk48cdn.net/shop/product/${id}/cgm48.png`);
        }
    }

    // Cherprang legacy
    if (mainFilename.startsWith('cherprang-1-')) {
        const currentNumMatch = mainFilename.match(/cherprang-1-(\d+)\.png/);
        const currentNum = currentNumMatch ? parseInt(currentNumMatch[1]) : 0;
        for (let i = 1; i <= 6; i++) {
            if (i === currentNum) continue;
            candidates.push(`https://img.bnk48cdn.net/shop/product/${id}/cherprang-1-${i}.png`);
        }
    }
    return candidates;
}

export const GET: RequestHandler = async ({ url }) => {
    const startRaw = parseInt(url.searchParams.get('start') || '0');
    const countRaw = parseInt(url.searchParams.get('count') || '50');
    const type = url.searchParams.get('type') || 'product';
    const order = url.searchParams.get('order') || 'asc';
    const includeSkus = url.searchParams.get('includeSkus') === 'true';

    // Validate inputs
    if (!ALLOWED_TYPES.has(type)) throw error(400, 'Invalid type parameter');
    if (!ALLOWED_ORDERS.has(order)) throw error(400, 'Invalid order parameter');
    if (isNaN(startRaw) || startRaw < 0) throw error(400, 'Invalid start parameter');
    if (isNaN(countRaw) || countRaw < 1) throw error(400, 'Invalid count parameter');

    const start = startRaw;
    const count = Math.min(countRaw, MAX_COUNT); // Enforce hard cap

    let ids: number[] = [];
    if (order === 'asc') {
        for (let i = start; i < start + count; i++) ids.push(i);
    } else {
        for (let i = start; i > start - count && i >= 0; i--) ids.push(i);
    }

    const batchSize = 20;
    const validAssets: { id: string; url: string; extra_skus?: string[] }[] = [];

    for (let i = 0; i < ids.length; i += batchSize) {
        const batchIds = ids.slice(i, i + batchSize);

        const batchResults = await Promise.all(
            batchIds.map(async (idNum) => {
                const id = idNum.toString();
                let foundFilename = '';
                let foundUrl = '';

                if (type === 'product') {
                    const candidates = getCDNDiscoveryUrls('product', idNum);
                    const checks = await Promise.all(
                        candidates.map(async (fullUrl) => {
                            const exists = await checkUrl(fullUrl);
                            if (exists) {
                                const parts = fullUrl.split('/');
                                const f = parts[parts.length - 1];
                                return { f, url: fullUrl };
                            }
                            return null;
                        })
                    );
                    const result = checks.find(r => r !== null);
                    if (result) {
                        foundFilename = result.f;
                        foundUrl = result.url;
                    }

                } else {
                    // Group type
                    const groupUrlJpg = `https://img.bnk48cdn.net/shop/product-group/${id}.jpg`;
                    const groupUrlPng = `https://img.bnk48cdn.net/shop/product-group/${id}.png`;
                    if (await checkUrl(groupUrlJpg)) {
                        foundUrl = groupUrlJpg;
                        foundFilename = `${id}.jpg`;
                    } else if (await checkUrl(groupUrlPng)) {
                        foundUrl = groupUrlPng;
                        foundFilename = `${id}.png`;
                    }
                }

                if (!foundUrl) return [];

                const mainAsset: { id: string; url: string; extra_skus: string[] } = {
                    id: idNum.toString(),
                    url: foundUrl.replace('https://img.bnk48cdn.net/', '/p/img/'),
                    extra_skus: []
                };

                if (type === 'product' && includeSkus) {
                    const skuUrls = getExtraSkusCandidates(id, foundFilename);
                    const skuResults = await Promise.all(
                        skuUrls.map(async (skuUrl) => {
                            const exists = await checkUrl(skuUrl);
                            return exists ? skuUrl.replace('https://img.bnk48cdn.net/', '/p/img/') : null;
                        })
                    );
                    mainAsset.extra_skus = skuResults.filter((r): r is string => r !== null);
                }

                return [mainAsset];
            })
        );

        validAssets.push(...batchResults.flat());
    }

    return json(validAssets, {
        headers: { 'Cache-Control': 'public, max-age=300' } // Cache 5 min
    });
};
