import { json } from '@sveltejs/kit';
import type { RequestHandler } from './$types';
import { getCDNDiscoveryUrls } from '$lib/bnk48';

async function checkExists(targetUrl: string): Promise<boolean> {
    const controller = new AbortController();
    const timeout = setTimeout(() => controller.abort(), 3000);
    try {
        const resp = await fetch(targetUrl, { 
            method: 'HEAD', 
            signal: controller.signal,
            headers: {
                'User-Agent': 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0.0.0 Safari/537.36',
                'Accept': '*/*'
            }
        });
        clearTimeout(timeout);
        return resp.ok;
    } catch {
        clearTimeout(timeout);
        return false;
    }
}

// คืน: true = มี, false = ไม่มี, null = network error (ไม่นับ)
async function probe(urls: string | string[]): Promise<boolean | null> {
    const urlList = Array.isArray(urls) ? urls : [urls];
    const controller = new AbortController();
    const timeout = setTimeout(() => controller.abort(), 5000);

    try {
        const results = await Promise.all(urlList.map(async (u) => {
            try {
                const resp = await fetch(u, { 
                    method: 'HEAD', 
                    signal: controller.signal,
                    headers: {
                        'User-Agent': 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0.0.0 Safari/537.36',
                        'Accept': '*/*'
                    }
                });
                return resp.ok;
            } catch {
                return null;
            }
        }));

        clearTimeout(timeout);

        if (results.some(r => r === true)) return true;
        if (results.every(r => r === false)) return false;
        return null;
    } catch {
        clearTimeout(timeout);
        return null;
    }
}

// Simple in-memory cache to prevent expensive linear searches on every request
const cache = new Map<string, { data: any; expires: number }>();
const CACHE_TTL = 1000 * 60 * 15; // 15 minutes

export const GET: RequestHandler = async ({ url }) => {
    const type = url.searchParams.get('type') || 'product';
    
    // Check cache
    const cached = cache.get(type);
    if (cached && cached.expires > Date.now()) {
        return json(cached.data);
    }
    
    let latest: { id: string; url: string } | null = null;

    function getCandidateUrls(id: number): string[] {
        return getCDNDiscoveryUrls(type as 'product' | 'group', id);
    }

    async function findWorkingUrl(id: number): Promise<string | null> {
        const urls = getCandidateUrls(id);
        for (const u of urls) {
            if (await checkExists(u)) return u;
        }
        return null;
    }

    console.log(`[API/Latest] Searching latest ${type}...`);
    const startTime = Date.now();
    
    // Improved Binary Search Algorithm
    let low = 0;
    let high = type === 'product' ? 26000 : 6000; // Realistic upper bounds
    let lastFoundId = 0;

    // Phase 1: Binary Search to find the general "latest" area
    while (low <= high) {
        const mid = Math.floor((low + high) / 2);
        const urls = getCandidateUrls(mid);
        const exists = await probe(urls);

        if (exists === true) {
            lastFoundId = mid;
            low = mid + 1;
        } else if (exists === false) {
            high = mid - 1;
        } else {
            // Timeout/Error: Try to move slightly to avoid the "dead" spot
            low++;
        }
    }

    // Phase 2: Check for small gaps (trailing check)
    let checkId = lastFoundId + 1;
    let gapLimit = 5; 
    while (gapLimit > 0 && checkId <= (type === 'product' ? 26000 : 6000)) {
        const exists = await probe(getCandidateUrls(checkId));
        if (exists === true) {
            lastFoundId = checkId;
            gapLimit = 5; 
        } else {
            gapLimit--;
        }
        checkId++;
    }

    if (lastFoundId > 0) {
        const finalUrl = await findWorkingUrl(lastFoundId);
        latest = { id: lastFoundId.toString(), url: finalUrl || getCandidateUrls(lastFoundId)[0] };
    }

    if (latest) {
        console.log(`[API/Latest] Found latest ${type}: ${latest.id} (Took ${Date.now() - startTime}ms)`);
        const prefix = 'img';
        const parsed = new URL(latest.url);
        const path = parsed.pathname.startsWith('/') ? parsed.pathname.slice(1) : parsed.pathname;
        const result = {
            id: latest.id,
            url: `/p/${prefix}/${path}`
        };
        
        // Save to cache
        cache.set(type, {
            data: result,
            expires: Date.now() + CACHE_TTL
        });
        
        return json(result);
    }
    return json({ id: '0', url: '' });
};