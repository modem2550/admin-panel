export const AUTH_URL = 'https://user.bnk48.io/auth/email';
export const INFO_URL = 'https://public.bnk48.io/content/member-live/video/';
export const TIMELINE_VIDEO_URL = 'https://user.bnk48.io/timeline-video/';
export const TIMELINE_INFO_URL = 'https://public.bnk48.io/timeline/';
export const BATCH_THANKYOU_URL = 'https://public.bnk48.io/timeline/content-member-batch-thankyou/';
export const M3U_URL = 'https://user.bnk48.io/member-live/';
export const MEMBER_URL = 'https://public.bnk48.io/member/';
export const PLAYBACK_URL_HEAD = 'https://app.bnk48.com/member-playback/';
export const API_V2_BASE = 'https://api.bnk48.com/api/v2';

// ── Types ──────────────────────────────────────────────────────────────────────
export interface MemberLive {
    id: string;
    title: string;
    thumbnailImageUrl: string;
    publishedAt: string;
}

export interface VODResult {
    resourceUrl: string;
    fileName: string;
    thumbnail: string;
    info: Record<string, any>;
}

export interface TimelineResult {
    resourceUrl: string | null;
    images: string[];
    fileName: string;
    thumbnail: string;
    info: Record<string, any>;
}

// ── proxyUrl — with memoization ───────────────────────────────────────────────

/** hostname → proxy prefix mapping (built once at module load) */
const HOST_PREFIX_MAP: Record<string, string> = {
    'img.bnk48cdn.net': 'img',
    'public.bnk48.io': 'pub',
    'user.bnk48.io': 'usr',
    'app.bnk48.com': 'app',
    'api.bnk48.com': 'api',
};

const proxyCache = new Map<string, string>();

/**
 * Proxies a URL through the project's own API to hide the original domain.
 * Uses a stealthy path-based approach: /p/{prefix}/{path}
 * Results are memoized — repeated calls with the same URL are O(1).
 */
export function proxyUrl(url: string | null | undefined): string {
    if (!url) return '';
    if (url.startsWith('/p/')) return url;
    if (!url.startsWith('http')) return url;

    const cached = proxyCache.get(url);
    if (cached !== undefined) return cached;

    let result = url;
    try {
        const parsed = new URL(url);
        const prefix = HOST_PREFIX_MAP[parsed.hostname];
        if (prefix) {
            const path = parsed.pathname.startsWith('/') ? parsed.pathname.slice(1) : parsed.pathname;
            result = `/p/${prefix}/${path}${parsed.search}`;
        }
    } catch {
        // ignore invalid URLs, return original
    }

    proxyCache.set(url, result);
    return result;
}

/**
 * Reverses a proxied URL back to its original domain.
 * Example: /p/usr/path -> https://user.bnk48.io/path
 */
export function unproxyUrl(proxiedUrl: string | null | undefined): string {
    if (!proxiedUrl) return '';
    if (!proxiedUrl.startsWith('/p/')) return proxiedUrl;

    const parts = proxiedUrl.slice(3).split('/');
    const prefix = parts[0];
    const pathWithSearch = parts.slice(1).join('/');

    // Reverse lookup for host
    const host = Object.keys(HOST_PREFIX_MAP).find(key => HOST_PREFIX_MAP[key] === prefix);
    if (!host) return proxiedUrl;

    return `https://${host}/${pathWithSearch}`;
}

export function getDefaultAssetUrl(type: 'product' | 'group' | 'theater', id: number | string): string {
    const idStr = String(id);
    if (type === 'group') return `/api/image/product-group/${idStr}.jpg`;
    if (type === 'theater') return '';
    return `/api/image/product/${idStr}/sku-1.jpg`;
}

// ── getCDNDiscoveryUrls ────────────────────────────────────────────────────────

export function getCDNDiscoveryUrls(type: 'product' | 'group' | 'theater', id: number | string): string[] {
    const idNum = +id;
    const idStr = String(id);

    if (type === 'group') {
        return [
            `https://img.bnk48cdn.net/shop/product-group/${idStr}.jpg`,
            `https://img.bnk48cdn.net/shop/product-group/${idStr}.png`,
        ];
    }
    if (type === 'theater') return [];

    // Seen set to deduplicate without post-processing
    const seen = new Set<string>();
    const candidates: string[] = [];

    const push = (path: string) => {
        const full = `https://img.bnk48cdn.net/shop/product/${idStr}/${path}`;
        if (!seen.has(full)) { seen.add(full); candidates.push(full); }
    };

    return candidates;
}